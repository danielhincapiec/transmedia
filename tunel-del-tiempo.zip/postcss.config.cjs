module.exports = {
  plugins: {
    'postcss-custom-media': {}
  }
};